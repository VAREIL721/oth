
<html>
<center>
<td>
<center><h2><b><font color=red>BATTLEFIELD</font></b></h2></center><br><br>
<img src="/images/bf2.png">
</center><br><br>
<div class="TableContainer">
	<div class="CaptionContainer">
		<div class="CaptionInnerContainer">
			<span class="CaptionEdgeLeftTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
			<span class="CaptionEdgeRightTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
			<span class="CaptionBorderTop" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);"></span>
			<span class="CaptionVerticalLeft" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span>
			<div class="Text">Informa&ccedil;&otilde;es BattleField Event</div>
			<span class="CaptionVerticalRight" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span>
			<span class="CaptionBorderBottom" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);"></span>
			<span class="CaptionEdgeLeftBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
			<span class="CaptionEdgeRightBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
				</div>
					</div>
						<table class="Table5" cellpadding="0" cellspacing="0">
							<tbody>
								<tr>
									<td>
									<div class="InnerTableContainer">
										<table style="width:100%;">
											<tbody>
												<tr>
													<td>
														<div class="TableShadowContainerRightTop">
															<div class="TableShadowRightTop" style="background-image:url('.$layout_name.'/images/content/table-shadow-rt.gif);"></div>
														</div>
													<div class="TableContentAndRightShadow" style="background-image:url('.$layout_name.'/images/content/table-shadow-rm.gif);">
													<div class="TableContentContainer">
<center>
<table width="100%" border="0" cellpadding="4" cellspacing="1">
<tbody>
	<tr>
		<td colspan="3" bgcolor="#f1e0c6"><span class="style4">
O evento é automático e acontece nos seguintes dias: <b>Sexta-feira, Sabado e Domingo às 20:00hrs</b>.</span><br>
		</td>
	</tr>
	<tr bgcolor="#d4c0a1"><td width="35%">
Um teleport será aberto no depot de Thais, e permanecerá aberto por 10 minutos.<br>
		</td>
	</tr>
	<td colspan="3" bgcolor="#f1e0c6"><span class="style4">
O Sistema irá balancear os times automaticamente;</span>
		</td>
	<tr bgcolor="#d4c0a1"><td width="35%">
Se o numero final de jogadores dentro do evento for impar, o sistema irá expulsar o ultimo jogador que ingressou no evento.<br>
		</td>
	</tr>
	<td colspan="3" bgcolor="#f1e0c6"><span class="style4">
Quando passar os 10 minutos de espera o teleport fechará e o tempo para as pedras sumir será de 2 minutos.</span><br>
		</td>
	<tr bgcolor="#d4c0a1"><td width="35%">
São formados por dois times, os "Black Assassins" e os "Red Barbarians".<br>
		</td>
	</tr>
	<td colspan="3" bgcolor="#f1e0c6"><span class="style4">
O sistema tem por finalidade matar todos do time inimigo, e os participantes que sobreviverem do time vencedor receberá a recompensa.</span><br>
		</td>
	<tr bgcolor="#d4c0a1"><td width="35%">
<b>OBS:</b> Quando morre no evento não perde nada (skill, level ou loot).	
		</td>
	</tr>
	<td colspan="3" bgcolor="#f1e0c6"><span class="style4">
<u><b>RECOMPENSA</u></b>: 10 bar of gold e 1 badge of glory. <i> (Moeda especial para troca por itens). Confira no <b>Events Shop</b>.</i></span><br>
		</td>
</tbody>
</table>
</center>
								</div>
									</div>
										<div class="TableShadowContainer">
											<div class="TableBottomShadow" style="background-image:url('.$layout_name.'/images/content/table-shadow-bm.gif);">
											<div class="TableBottomLeftShadow" style="background-image:url('.$layout_name.'/images/content/table-shadow-bl.gif);"></div>
											<div class="TableBottomRightShadow" style="background-image:url('.$layout_name.'/images/content/table-shadow-br.gif);"></div>
										</div>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</td>
			</tr>
		</tbody>
	</table>
</div>
</html> 