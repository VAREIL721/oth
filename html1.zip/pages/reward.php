
 <center><font size='5'><b>Reward Chest System</b></font></center>
<br>
<center><img src='/images/Reward.png'/></center>
<br>
<br>

<table style='width:90%;margin-left:auto;margin-right:auto'><tr bgcolor='#505050'><td colspan='2' style='color:white;font-weight:bold'><img src='/images/estr.gif'/> Fatores de Participação</td></tr>
<tr bgcolor='#D4C0A1'><td colspan='2' font-weight:bold'>Blockar a criatura para não escapar e receber danos contará pontos.</td></tr>
<tr bgcolor='#D4C0A1'><td colspan='2' font-weight:bold'>Se o jogador está dando suporte na luta contra o boss, curando membros que estão participando ou atacando o boss então contará pontos.</td></tr></table><br><br><br>

<table style='width:90%;margin-left:auto;margin-right:auto'><tr bgcolor='#505050'><td colspan='2' style='color:white;font-weight:bold'><img src='/images/estr.gif'/> Constituição do Loot</td><td colspan='2' style='color:white;font-weight:bold'>Pontuação</td><td colspan='2' style='color:white;font-weight:bold'>Nível</td></tr>
<tr bgcolor='#D4C0A1'><td colspan='2' font-weight:bold'>Item Comum</td><td colspan='2' font-weight:bold'>10~40pts</td><td colspan='2' font-weight:bold'>1</td></tr>
<tr bgcolor='#D4C0A1'><td colspan='2' font-weight:bold'>Item Comum + Item Semi raro</td><td colspan='2' font-weight:bold'>40~60pts</td><td colspan='2' font-weight:bold'>2</td></tr>
<tr bgcolor='#D4C0A1'><td colspan='2' font-weight:bold'>Item Comum + Item Semi raro + Item Raro</td><td colspan='2' font-weight:bold'>60~80pts</td><td colspan='2' font-weight:bold'>3</td></tr>
<tr bgcolor='#D4C0A1'><td colspan='2' font-weight:bold'>Item Comum + Item Semi raro + Item Raro + Item Muito Raro</td><td colspan='2' font-weight:bold'>80~95pts</td><td colspan='2' font-weight:bold'>4</td></tr>
<tr bgcolor='#D4C0A1'><td colspan='2' font-weight:bold'>Item Comum + Item Semi raro + Item Raro + Item Cai Sempre</td><td colspan='2' font-weight:bold'>96~100pts</td><td colspan='2' font-weight:bold'>5</td></tr></table><br><br><br>

<table style='width:90%;margin-left:auto;margin-right:auto'><tr bgcolor='#505050'><td colspan='2' style='color:white;font-weight:bold'><img src='/images/estr.gif'/> Onde receber sua recompensa</td></tr>
<tr bgcolor='#D4C0A1'><td colspan='2' font-weight:bold'> Apos o boss ser morto o jogador deve se dirigir ao depot de qualquer cidade e ir até o depot locker, la você receberá sua recompensa.</td></tr></table><br><br><br>

<table style='width:90%;margin-left:auto;margin-right:auto'>
<tr bgcolor='#505050'><td colspan='2' style='color:white;font-weight:bold'><img src='/images/estr.gif'/> Bosses que fazem parte desse sistema</td></tr>
<table style='width:90%;margin-left:auto;margin-right:auto'>
<tr bgcolor='#D4C0A1'><td style='font-weight:bold;width:120px'><center><img src='http://tibiawiki.com.br/images/0/0f/Ferumbras.gif'/><br><u>Ferumbras<br></center></u><br>
<td style='font-weight:bold;width:120px'><center><img src='http://tibiawiki.com.br/images/c/ce/Orshabaal.gif'/><br><u>Orshabaal<br></center></u><br></td>
<td style='font-weight:bold;width:120px'><center><img src='http://tibiawiki.com.br/images/c/ce/Morgaroth.gif'/><br><u>Morgaroth<br></center></u><br></td>
<td style='font-weight:bold;width:120px'><center><img src='http://tibiawiki.com.br/images/5/5e/Ghazbaran.gif'/><br><u>Ghazbaran<br></center></u><br></td>
<td style='font-weight:bold;width:120px'><center><img src='http://tibiawiki.com.br/images/6/63/Gaz%27Haragoth.gif'/><br><u>Gaz'haragoth</u><br></center></td></tr></table>
<table style='width:90%;margin-left:auto;margin-right:auto'>
<tr bgcolor='#D4C0A1'><td style='font-weight:bold;width:120px'><center><img src='http://tibiawiki.com.br/images/2/2f/Mad_Mage.gif'/><br><u>Mad Mage<br></center></u><br></td>
<td style='font-weight:bold;width:120px'><center><img src='/images/branco.gif'/><br><br></center></u><br></td>
<td style='font-weight:bold;width:120px'><center><img src='/images/branco.gif'/><br><br></center></u><br></td>
<td style='font-weight:bold;width:120px'><center><img src='/images/branco.gif'/><br><br></center></u><br></td>
<td style='font-weight:bold;width:120px'><center><img src='/images/branco.gif'/><br><br></center></u><br></td></tr></table></table>
<br><br><br>

