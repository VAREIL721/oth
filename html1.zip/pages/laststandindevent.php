
<html>
<center>
<td>
<center><h2><b><font color=red>Last Standing Event</font></b></h2></center><br><br>
<img src="images/last.png">
</center><br><br>
<div class="TableContainer">
	<div class="CaptionContainer">
		<div class="CaptionInnerContainer">
			<span class="CaptionEdgeLeftTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
			<span class="CaptionEdgeRightTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
			<span class="CaptionBorderTop" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);"></span>
			<span class="CaptionVerticalLeft" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span>
			<div class="Text"><center>Informa&ccedil;&otilde;es:</center></div>
			<span class="CaptionVerticalRight" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span>
			<span class="CaptionBorderBottom" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);"></span>
			<span class="CaptionEdgeLeftBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
			<span class="CaptionEdgeRightBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
				</div>
					</div>
						<table class="Table5" cellpadding="0" cellspacing="0">
							<tbody>
								<tr>
									<td>
									<div class="InnerTableContainer">
										<table style="width:100%;">
											<tbody>
												<tr>
													<td>
														<div class="TableShadowContainerRightTop">
															<div class="TableShadowRightTop" style="background-image:url('.$layout_name.'/images/content/table-shadow-rt.gif);"></div>
														</div>
													<div class="TableContentAndRightShadow" style="background-image:url('.$layout_name.'/images/content/table-shadow-rm.gif);">
													<div class="TableContentContainer">
<center>
<table width="100%" border="0" cellpadding="4" cellspacing="1">
<tbody>
	<tr>
		<td colspan="3" bgcolor="#f1e0c6"><span class="style4">
Last standing man é um evento automático que ocorre todos os dias em horarios aleatórios, o teleport para o acesso ao evento é aberto no templo de thais e ficará acessivel durante 3 minutos, ao passar este tempo o teleport é fechado e começará o evento. Os players terão um tempo de +1 minuto para se organizar antes de abrir o gate para batalhar. <center><br><br><b>Restrições:</b><br> <font color="red"><b>Limite máximo de 100 players.</b><br><b>Não é permitido MC.</b><br><b>Apenas level 150+ entram no evento.</b></font><br>
</center></span><br>
		</td>
	</tr>
	<tr bgcolor="#d4c0a1"><td width="35%">
<b><center>Como funciona?</b></center><br>
		</td>
	</tr>
	<td colspan="3" bgcolor="#f1e0c6"><span class="style4">
Ao entrar no teleport, voce sera levado para uma sala de espera até dar o tempo do inicio do evento. O objetivo será eliminar todos os componentes . O ultimo sobrevivente ganhará a recompensa. <b>PS:</b> Não perde level, skills e nem items dentro do evento!<center><b><br><br>Prêmio:</b><br>5 Event Coins<br>
</center></span>
		</td>
</tbody>
</table>
</center>
								</div>
									</div>
										<div class="TableShadowContainer">
											<div class="TableBottomShadow" style="background-image:url('.$layout_name.'/images/content/table-shadow-bm.gif);">
											<div class="TableBottomLeftShadow" style="background-image:url('.$layout_name.'/images/content/table-shadow-bl.gif);"></div>
											<div class="TableBottomRightShadow" style="background-image:url('.$layout_name.'/images/content/table-shadow-br.gif);"></div>
										</div>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</td>
			</tr>
		</tbody>
	</table>
</div>
</html> 