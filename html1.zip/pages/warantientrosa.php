
	<center><h1>Área Anti-Entrosa<h1></center>
</center>


<br><br>O Sistema anti entrosa foi desenvolvido por nossa equipe do aurera-global para que as guilds travem batalhas sem que outros jogadores atrapalhem a performace, o sistema permite que 2 guilds acessem o mapa escolhido, o tempo determinado para cada batalha é padrão(60 minutos), porém o sistema permite que os jogadores se mantenham no local duelando até que outra guild solicite acesso ao mapa, ou seja se a guild 1 está duelando com a guild 2 e já se passaram 60 minutos e a guild 3 foi la e solicitou guerra com outra guild automaticamente todos que estão no mapa serão enviados para o templo da cidade natal do personagem, caso contrario as guilds 1 e 2 continuam a utilizar o mapa.<br><br>
Após o lider da guild enviar o convite para a guild inimiga, o lider da guild inimiga terá 2 minutos para aceitar, nesse curto periodo de tempo nenhuma guild pode invitar no mesmo mapa até que o convite seja rejeitado automaticamente, ou seja o mapa já está parcialmente ocupado.<br><br>
Nosso sistema de war anti entrosa pode ser configurado pelos lideres de guild no momento do convite de acordo com as informações abaixo.<br>


<center><h2><u>ENVIANDO CONVITE</u>:</h2></center><br><br>
<b>➥ /citywar map,invite,EnemyGuild,parametro1,parametro2,parametro3,parametro4</b>
<font color="red"><small>(O lider convida a guild inimiga para área anti-entrosa)</small></font><br><br><br>
<b>► Map:</b><font color="red"><small> (escolha uma opção)</small></font>
<br>
<br>
<b><small><font color="green">✔ Edron</font></b>: Mapa Edron vs Cormaya
<br>
<br>
<b><font color="green">✔ Carlin </font></b>: Cidade de Carlin
<br>
<br>
<b><font color="green">✔ Darashia</font></b>: Cidade de Darashia 
<br>
<br>
<b><font color="green">✔ Ankrahmun</font></b>: Cidade de Ankrahmun
<br>
<br>
<b><font color="green">✔ Libertybay</font></b>: Cidade de Libety bay </small>
<br>
<br>
<b>► Parametro1:</b><font color="red"><small> (escolha uma opção)</small></font>
<small><br><br><b><font color="green">✔ default</font></b>: Padrão, libera todas runas e spells informadas na opção posterior
<br>
<br>
<b><font color="green">✔ onlysd</font></b>: bloqueia as seguintes <b>RUNAS</b>: <font color="red">avalanche, great fireball, thunderstorm, stone shower e </font><b>SPELLS:</b> <font color="red">exevo vis hur, exevo tera hur, exevo frigo hur, exevo gran frigo hur, exevo flam hur, exevo mas san, exevo gran vis lux.</font></small>
<br>
<br>
<b>► Parametro2:</b><font color="red"><small> (escolha uma opção)</small></font>
<small>
<br>
<br>
<b><font color="green">✔ default</font></b>: Padrão, libera todas spells de area informadas na opção posterior
<br>
<br><b><font color="green">✔ notue</font></b>: bloqueia as seguintes <b>SPELLS</b>: <font color="red">exevo gran mas flam, exevo gran mas vis, exevo gran mas frigo, exevo gran mas tera.</font></small>
<br>
<br>
<b>
► Parametro3:</b><font color="red"><small> (escolha uma opção)</small></font>
<small><br><br><b>
<font color="green">✔ default</b></font>: Padrão, sem limite de players
<br>
<br>
<b><font color="green">✔ 10x10</font></b>: Apenas 10 jogadores de cada guild poderá acessar o local
<br>
<br>
<b><font color="green">✔ 15x15</font></b>: Apenas 15 jogadores de cada guild poderá acessar o local
<br>
<br>
<b><font color="green">✔ 20x20</font></b>: Apenas 20 jogadores de cada guild poderá acessar o local
</font>
<br>
<br>
<b><font color="green">✔ 25x25</font></b>: Apenas 25 jogadores de cada guild poderá acessar o local
</font>
<br>
<br>
<b><font color="green">✔ 30x30</font></b>: Apenas 30 jogadores de cada guild poderá acessar o local
</font>
<br>
<br>
<b><font color="green">✔ 35x35</font></b>: Apenas 35 jogadores de cada guild poderá acessar o local
</font>
<br>
<br>
<b><font color="green">✔ 40x40</font></b>: Apenas 40 jogadores de cada guild poderá acessar o local
</font>
<br>
<br>
<b><font color="green">✔ 45x45</font></b>: Apenas 45 jogadores de cada guild poderá acessar o local
</font>
<br>
<br>
<b><font color="green">✔ 50x50</font></b>: Apenas 50 jogadores de cada guild poderá acessar o local
</font></small>
<br>
<br>
<b>
► Parametro4:</b><font color="red"><small> (escolha uma opção)</small></font>
<small><br><br><b>
<font color="green">✔ default</b></font>: liberado uso de todas as potions
<br>
<br>
<b><font color="green">✔ notpotions</font></b>: bloqueia o uso de <b>Ultimate Mana Potion, Ultimate Spirit Potion e Supreme Health Potion</b>.
<br>
<br>

<center><h2><u>ACEITANDO CONVITE</u>:</h2></center><br><br>
<b>➥ /citywar map,accept,GuildName</b>
<font color="red"><small>(A guild inimiga aceita para ir a área anti-entrosa)</small></font>
<br>
<br>
<center><h2><u>INDO PARA LOCAL DE BATALHA</u>:</h2></center><br><br>
<b>➥ /citywar map,enter</b>
<font color="red"><small>(Depois de ter invitado e aceitado, ambas guilds podem usar para entrar no local)</small></font>
<br>
<br>

<h2>Exemplo de como usar:</h2>
Minha guild é <b>GUILD 1</b>, a guild inimiga é <b>GUILD 2</b> e eu escolhi a cidade de <b>EDRON</b>, permitindo apenas <b>SUDDEN DEATH RUNE</b>, bloqueando <b>MAGIAS DE ÁREA</b>, com limite de <b>15x15</b> e bloqueando as novas potions:<br>
<br>
<font color="red">➥ /citywar <b>edron</b>,invite,GUILD 2,<b>onlysd</b>,<b>notue</b>,<b>15x15</b>,notpotions</font>
<br><br>
O lider da guild <b>GUILD 2</b> deve utilizar o seguinte comando para aceitar:<br><br>
<font color="red">➥ /citywar <b>edron</b>,accept,<b>GUILD 1</b></font>
<br>
<br>
Para entrar no local de batalha, ambas as guilds devem utilizar:<br><br>
<font color="red">➥ /citywar <b>edron</b>,enter</font>

<br><br>Nossa equipe está trabalhando sempre para melhorar nosso sistema de anti entrosa, se você tem alguma ideia e gostaria que fosse implantado, envie-nos um ticket explicando e se aceito por nossa equipe será implantado.
