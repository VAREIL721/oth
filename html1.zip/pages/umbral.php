<div align="center"><center><img src="http://i.imgur.com/f4xlzdO.png" width="531" height="58"><br>
							<img src="http://i.imgur.com/QV5pLgx.png" width="370" height="413"></center><br><div class="TableContainer">
        <div class="CaptionContainer">
                        <div class="CaptionInnerContainer">
                                <span class="CaptionEdgeLeftTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionEdgeRightTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionBorderTop" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif)"></span>
                                <span class="CaptionVerticalLeft" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif)"></span>
                                <div class="Text"><center>Est&aacute;gio Bruto (Crude)</center></div>
                                <span class="CaptionVerticalRight" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif)"></span>
                                <span class="CaptionBorderBottom" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif)"></span>
                                <span class="CaptionEdgeLeftBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionEdgeRightBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                        </div>
                </div>
				<table cellpadding="4" cellspacing="1" width="100%" border="0">
				<TR BGCOLOR="#D4C0A1">
				<TD><img src="/images/icon_2.gif" alt="" width="8" height="11"> Para conseguir as armas mais fracas, voc&ecirc; deve entregar <b>1 Dream Matter</b> e <b>20 Clusters of Solace</b> para Eruaran. Caso Eruaran falhe voc&ecirc; <u>perde</u> os 20 Clusters of Solace utilizados.
				<br><img src="/images/icon_2.gif" alt="" width="8" height="11"> Para criar itens voc&ecirc; deve falar "create", o tipo da arma (one handed, two handed ou outros) e "yes" para Eruaran.
				</TD>
				</tr>
				</table>
				</div><div class="TableContainer">
        <div class="CaptionContainer">
                        <div class="CaptionInnerContainer">
                                <span class="CaptionEdgeLeftTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionEdgeRightTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionBorderTop" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif)"></span>
                                <span class="CaptionVerticalLeft" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif)"></span>
                                <div class="Text"><center>Crude Umbral Itens</center></div>
                                <span class="CaptionVerticalRight" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif)"></span>
                                <span class="CaptionBorderBottom" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif)"></span>
                                <span class="CaptionEdgeLeftBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionEdgeRightBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                        </div>
                </div>
				<table cellpadding="4" cellspacing="1" width="100%" border="0">
				<TR BGCOLOR="#D4C0A1">
						<TD width="3%" ><b><center>img</center</b></TD>
                        <TD width="20%" ><b><center>Nome</center></b></TD>
						<TD width="50%" ><b><center>Atributos</center></b></TD>
                </TR>
				<tr bgcolor="#F1E0C6">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/0/0b/Crude_Umbral_Blade.gif" width="32" height="32"></div></td>
                  <td><div align="left">Crude Umbral Blade</div></td>
                  <td><div align="center">Atk: 48, Def: 26 +1</div></td>
                </tr>
				<tr bgcolor="#D4C0A1">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/b/bd/Crude_Umbral_Slayer.gif" width="32" height="32"></div></td>
                  <td><div align="left">Crude Umbral Slayer</div></td>
                  <td><div align="center">Atk: 51, Def: 29</div></td>
                </tr>
				<tr bgcolor="#F1E0C6">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/3/31/Crude_Umbral_Axe.gif" width="32" height="32"></div></td>
                  <td><div align="left">Crude Umbral Axe</div></td>
                  <td><div align="center">Atk: 49, Def: 24 +1</div></td>
                </tr>
				<tr bgcolor="#D4C0A1">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/f/f9/Crude_Umbral_Chopper.gif" width="32" height="32"></div></td>
                  <td><div align="left">Crude Umbral Chopper</div></td>
                  <td><div align="center">Atk: 51, Def: 27</div></td>
                </tr>
				<tr bgcolor="#F1E0C6">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/c/cd/Crude_Umbral_Hammer.gif" width="32" height="32"></div></td>
                  <td><div align="left">Crude Umbral Hammer</div></td>
                  <td><div align="center">Atk: 51, Def: 27</div></td>
                </tr>
				<tr bgcolor="#D4C0A1">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/5/51/Crude_Umbral_Mace.gif" width="32" height="32"></div></td>
                  <td><div align="left">Crude Umbral Mace</div></td>
                  <td><div align="center">Atk: 48, Def: 22 +1</div></td>
                </tr>
				<tr bgcolor="#F1E0C6">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/3/33/Crude_Umbral_Bow.gif" width="32" height="32"></div></td>
                  <td><div align="left">Crude Umbral Bow</div></td>
                  <td><div align="center">Atk: +2, Range:7, Hit% +5</div></td>
                </tr>
				<tr bgcolor="#D4C0A1">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/f/f4/Crude_Umbral_Crossbow.gif" height="32"></div></td>
                  <td><div align="left">Crude Umbral Crossbow</div></td>
                  <td><div align="center">Atk: +3, Range:5, Hit% +1</div></td>
                </tr>
				<tr bgcolor="#F1E0C6">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/5/50/Crude_Umbral_Spellbook.gif" width="32" height="32"></div></td>
                  <td><div align="left">Crude Umbral Spellbook</div></td>
                  <td><div align="center">Def: 14, Magic Level +1, Earth +2%, Energy +2%, Fire +2%, Ice +2%</div></td>
                </tr>
				</table></div><br><br><div class="TableContainer">
					<div class="CaptionContainer">
                        <div class="CaptionInnerContainer">
                                <span class="CaptionEdgeLeftTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionEdgeRightTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionBorderTop" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif)"></span>
                                <span class="CaptionVerticalLeft" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif)"></span>
                                <div class="Text"><center>Est&aacute;gio Umbral</center></div>
                                <span class="CaptionVerticalRight" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif)"></span>
                                <span class="CaptionBorderBottom" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif)"></span>
                                <span class="CaptionEdgeLeftBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionEdgeRightBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                        </div>
                </div>
				<table cellpadding="4" cellspacing="1" width="100%" border="0">
				<TR BGCOLOR="#D4C0A1">
				<TD><img src="/images/icon_2.gif" alt="" width="8" height="11"> Para conseguir as armas umbrais, voc&ecirc; deve entregar o respectivo item de qualidade inferior, no caso, o <b>crude</b> e <b>75 Clusters of Solace</b> para Eruaran. Caso Eruaran falhe voc&ecirc; <u>perde</u> sua arma crude, e mant&ecirc;m os 75 Clusters of Solace ou <u>perde</u> sua arma crude e os 75 Clusters of Solace.
				<br><img src="/images/icon_2.gif" alt="" width="8" height="11"> Para melhorar o item para o segundo est&aacute;gio voc&ecirc; deve falar "improve", o tipo da arma (one handed, two handed ou outros) e "yes" para Eruaran.
				</TD>
				</tr>
				</table>
				</div><div class="TableContainer">
						<div class="CaptionContainer">
                        <div class="CaptionInnerContainer">
                                <span class="CaptionEdgeLeftTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionEdgeRightTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionBorderTop" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif)"></span>
                                <span class="CaptionVerticalLeft" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif)"></span>
                                <div class="Text"><center>Umbral Itens</center></div>
                                <span class="CaptionVerticalRight" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif)"></span>
                                <span class="CaptionBorderBottom" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif)"></span>
                                <span class="CaptionEdgeLeftBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionEdgeRightBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                        </div>
                </div>
				<table cellpadding="4" cellspacing="1" width="100%" border="0">
				<TR BGCOLOR="#D4C0A1">
						<TD width="3%" ><b><center>img</center</b></TD>
                        <TD width="20%" ><b><center>Nome</center></b></TD>
						<TD width="50%" ><b><center>Atributos</center></b></TD>
                </TR>
				<tr bgcolor="#F1E0C6">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/a/ae/Umbral_Blade.gif" width="32" height="32"></div></td>
                  <td><div align="left">Umbral Blade</div></td>
                  <td><div align="center">Atk: 50, Def: 29 +2</div></td>
                </tr>
				<tr bgcolor="#D4C0A1">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/1/1d/Umbral_Slayer.gif" width="32" height="32"></div></td>
                  <td><div align="left">Umbral Slayer</div></td>
                  <td><div align="center">Atk: 52, Def: 31</div></td>
                </tr>
				<tr bgcolor="#F1E0C6">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/b/b0/Umbral_Axe.gif" width="32" height="32"></div></td>
                  <td><div align="left">Umbral Axe</div></td>
                  <td><div align="center">Atk: 51, Def: 27 +2</div></td>
                </tr>
				<tr bgcolor="#D4C0A1">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/2/27/Umbral_Chopper.gif" width="32" height="32"></div></td>
                  <td><div align="left">Umbral Chopper</div></td>
                  <td><div align="center">Atk: 52, Def: 30</div></td>
                </tr>
				<tr bgcolor="#F1E0C6">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/4/4a/Umbral_Hammer.gif" width="32" height="32"></div></td>
                  <td><div align="left">Umbral Hammer</div></td>
                  <td><div align="center">Atk: 53, Def: 30</div></td>
                </tr>
				<tr bgcolor="#D4C0A1">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/4/46/Umbral_Mace.gif" width="32" height="32"></div></td>
                  <td><div align="left">Umbral Mace</div></td>
                  <td><div align="center">Atk: 50, Def: 26 +2</div></td>
                </tr>
				<tr bgcolor="#F1E0C6">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/1/1c/Umbral_Bow.gif" width="32" height="32"></div></td>
                  <td><div align="left">Umbral Bow</div></td>
                  <td><div align="center">Atk: +4, Range:7, Hit% +5</div></td>
                </tr>
				<tr bgcolor="#D4C0A1">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/8/81/Umbral_Crossbow.gif" height="32"></div></td>
                  <td><div align="left">Umbral Crossbow</div></td>
                  <td><div align="center">Atk: +6, Range:5, Hit% +2</div></td>
                </tr>
				<tr bgcolor="#F1E0C6">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/e/e3/Umbral_Spellbook.gif" width="32" height="32"></div></td>
                  <td><div align="left">Umbral Spellbook</div></td>
                  <td><div align="center">Def: 16, Magic Level +2, Earth +3%, Energy +3%, Fire +3%, Ice +3%</div></td>
                </tr>
				</table></div><br><br><div class="TableContainer">
					<div class="CaptionContainer">
                        <div class="CaptionInnerContainer">
                                <span class="CaptionEdgeLeftTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionEdgeRightTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionBorderTop" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif)"></span>
                                <span class="CaptionVerticalLeft" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif)"></span>
                                <div class="Text"><center>Est&aacute;gio Master</center></div>
                                <span class="CaptionVerticalRight" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif)"></span>
                                <span class="CaptionBorderBottom" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif)"></span>
                                <span class="CaptionEdgeLeftBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionEdgeRightBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                        </div>
                </div>
				<table cellpadding="4" cellspacing="1" width="100%" border="0">
				<TR BGCOLOR="#D4C0A1">
				<TD><img src="/images/icon_2.gif" alt="" width="8" height="11"> Para conseguir as armas masters, voc&ecirc; deve entregar o respectivo item de qualidade <b>umbral</b>, e <b>150 Clusters of Solace</b> para Eruaran. Caso Eruaran falhe voc&ecirc; <u>perde</u> sua arma umbral e mant&eacute;m os 150 Clusters of Solace ou sua arma umbral volta para o est&aacute;gio crude e voc&ecirc; <u>perde</u> 75 Clusters of Solace.
				<br><img src="/images/icon_2.gif" alt="" width="8" height="11"> Para melhorar seu item para o terceiro est&aacute;gio voc&ecirc; deve falar "transform", o tipo da arma (one handed, two handed ou outros) e "yes" para Eruaran.
				</TD>
				</tr>
				</table>
				</div><div class="TableContainer">
        <div class="CaptionContainer">
                        <div class="CaptionInnerContainer">
                                <span class="CaptionEdgeLeftTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionEdgeRightTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionBorderTop" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif)"></span>
                                <span class="CaptionVerticalLeft" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif)"></span>
                                <div class="Text"><center>Umbral Master Itens</center></div>
                                <span class="CaptionVerticalRight" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif)"></span>
                                <span class="CaptionBorderBottom" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif)"></span>
                                <span class="CaptionEdgeLeftBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionEdgeRightBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                        </div>
                </div>
				<table cellpadding="4" cellspacing="1" width="100%" border="0">
				<TR BGCOLOR="#D4C0A1">
						<TD width="3%" ><b><center>img</center</b></TD>
                        <TD width="20%" ><b><center>Nome</center></b></TD>
						<TD width="50%" ><b><center>Atributos</center></b></TD>
                </TR>
				<tr bgcolor="#F1E0C6">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/7/7a/Umbral_Masterblade.gif" width="32" height="32"></div></td>
                  <td><div align="left">Umbral Masterblade</div></td>
                  <td><div align="center">Atk: 52, Def: 31 +3, Sword Fighting +1</div></td>
                </tr>
				<tr bgcolor="#D4C0A1">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/4/42/Umbral_Master_Slayer.gif" width="32" height="32"></div></td>
                  <td><div align="left">Umbral Master Slayer</div></td>
                  <td><div align="center">Atk: 54, Def: 35, Sword Fighting +3</div></td>
                </tr>
				<tr bgcolor="#F1E0C6">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/f/ff/Umbral_Master_Axe.gif" width="32" height="32"></div></td>
                  <td><div align="left">Umbral Master Axe</div></td>
                  <td><div align="center">Atk: 53, Def: 30 +3, Axe Fighting +1</div></td>
                </tr>
				<tr bgcolor="#D4C0A1">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/9/9a/Umbral_Master_Chopper.gif" width="32" height="32"></div></td>
                  <td><div align="left">Umbral Master Chopper</div></td>
                  <td><div align="center">Atk: 54, Def: 34, Axe Fighting +3</div></td>
                </tr>
				<tr bgcolor="#F1E0C6">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/6/69/Umbral_Master_Hammer.gif" width="32" height="32"></div></td>
                  <td><div align="left">Umbral Master Hammer</div></td>
                  <td><div align="center">Atk: 55, Def: 34, Club Fighting +3</div></td>
                </tr>
				<tr bgcolor="#D4C0A1">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/c/c1/Umbral_Master_Mace.gif" width="32" height="32"></div></td>
                  <td><div align="left">Umbral Master Mace</div></td>
                  <td><div align="center">Atk: 52, Def: 30 +3, Club Fighting +1</div></td>
                </tr>
				<tr bgcolor="#F1E0C6">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/f/f7/Umbral_Master_Bow.gif" width="32" height="32"></div></td>
                  <td><div align="left">Umbral Master Bow</div></td>
                  <td><div align="center">Atk: +6, Range:7, Hit% +5</div></td>
                </tr>
				<tr bgcolor="#D4C0A1">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/8/81/Umbral_Master_Crossbow.gif" height="32"></div></td>
                  <td><div align="left">Umbral Master Crossbow</div></td>
                  <td><div align="center">Atk: +9, Range:5, Hit% +4</div></td>
                </tr>
				<tr bgcolor="#F1E0C6">
                  <td><div align="center"><img src="http://tibiawiki.com.br/images/9/9c/Umbral_Master_Spellbook.gif" width="32" height="32"></div></td>
                  <td><div align="left">Umbral Master Spellbook</div></td>
                  <td><div align="center">Def: 20, Magic Level +4, Earth +5%, Energy +5%, Fire +5%, Ice +5%</div></td>
                </tr>
				</table></div></div><br><br><div class="TableContainer">
        <div class="CaptionContainer">
                        <div class="CaptionInnerContainer">
                                <span class="CaptionEdgeLeftTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionEdgeRightTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionBorderTop" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif)"></span>
                                <span class="CaptionVerticalLeft" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif)"></span>
                                <div class="Text"><center>Localiza&ccedil;&atilde;o</center></div>
                                <span class="CaptionVerticalRight" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif)"></span>
                                <span class="CaptionBorderBottom" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif)"></span>
                                <span class="CaptionEdgeLeftBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionEdgeRightBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                        </div>
                </div> 
				<table BGCOLOR="#D4C0A1" cellpadding="4" cellspacing="1" width="100%" border="0">
				<center><img src="http://portaltibia.com.br/wp-content/uploads/2013/11/roshamuul.png" width="440" height="220"></center>
				<br>        
				</table></div><br><br><div class="TableContainer">
        <div class="CaptionContainer">
                        <div class="CaptionInnerContainer">
                                <span class="CaptionEdgeLeftTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionEdgeRightTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionBorderTop" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif)"></span>
                                <span class="CaptionVerticalLeft" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif)"></span>
                                <div class="Text"><center><img src="http://www.tibiawiki.com.br/images/f/ff/Achievement.gif" width="16" height="16"> Achievements <img src="http://www.tibiawiki.com.br/images/f/ff/Achievement.gif" width="16" height="16"></center></div>
                                <span class="CaptionVerticalRight" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif)"></span>
                                <span class="CaptionBorderBottom" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif)"></span>
                                <span class="CaptionEdgeLeftBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionEdgeRightBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                        </div>
                </div> 
				<table cellpadding="4" cellspacing="1" width="100%" border="0">
				<TR BGCOLOR="#F1E0C6">
				<TD ><center>Ao conseguir transformar itens do est&aacute;gio <b>"Umbral"</b> para <b>"Master"</b> os jogadores receber&atilde;o achievements.</center></TD>
				</TR>
				<TR BGCOLOR="#D4C0A1">
				<table cellpadding="4" cellspacing="1" width="100%" border="0">
				
				<TR BGCOLOR="#D4C0A1">
						<TD width="10%" ><b><center>grado</center></b></TD>
                        <TD width="20%" ><b><center>Achievement</center></b></TD>
						<TD width="50%" ><b><center>Atributos</center></b></TD>
                </TR>
				<tr bgcolor="#F1E0C6">
					<td><div align="center"><img src="http://www.tibiawiki.com.br/images/f/ff/Achievement.gif" width="16" height="16"> <img src="http://www.tibiawiki.com.br/images/f/ff/Achievement.gif" width="16" height="16"></div></td>
					<td><div align="center">Umbral Archer</div></td>
					<td><div align="center">Obtido ao criar um <b>Umbral Master Bow</b>.</div></td>
                </tr>
				<tr bgcolor="#D4C0A1">
					<td><div align="center"><img src="http://www.tibiawiki.com.br/images/f/ff/Achievement.gif" width="16" height="16"> <img src="http://www.tibiawiki.com.br/images/f/ff/Achievement.gif" width="16" height="16"></div></td>
                  <td><div align="center">Umbral Berserker</div></td>
                  <td><div align="center">Obtido ao criar um <b>Umbral Master Hammer</b>.</div></td>
                </tr>
				<tr bgcolor="#F1E0C6">
					<td><div align="center"><img src="http://www.tibiawiki.com.br/images/f/ff/Achievement.gif" width="16" height="16"> <img src="http://www.tibiawiki.com.br/images/f/ff/Achievement.gif" width="16" height="16"></div></td>
                  <td><div align="center">Umbral Bladelord</div></td>
                  <td><div align="center">Obtido ao criar uma <b>Umbral Masterblade</b>.</div></td>
                </tr>
				<tr bgcolor="#D4C0A1">
					<td><div align="center"><img src="http://www.tibiawiki.com.br/images/f/ff/Achievement.gif" width="16" height="16"> <img src="http://www.tibiawiki.com.br/images/f/ff/Achievement.gif" width="16" height="16"></div></td>
                  <td><div align="center">Umbral Brawler</div></td>
                  <td><div align="center">Obtido ao criar um <b>Umbral Master Mace</b>.</div></td>
                </tr>
				<tr bgcolor="#F1E0C6">
				<td><div align="center"><img src="http://www.tibiawiki.com.br/images/f/ff/Achievement.gif" width="16" height="16"> <img src="http://www.tibiawiki.com.br/images/f/ff/Achievement.gif" width="16" height="16"></div></td>
                  <td><div align="center">Umbral Executioner</div></td>
                  <td><div align="center">Obtido ao criar um <b>Umbral Master Chopper</b>.</div></td>
                </tr>
				<tr bgcolor="#D4C0A1">
				<td><div align="center"><img src="http://www.tibiawiki.com.br/images/f/ff/Achievement.gif" width="16" height="16"> <img src="http://www.tibiawiki.com.br/images/f/ff/Achievement.gif" width="16" height="16"></div></td>
                  <td><div align="center">Umbral Harbinger</div></td>
                  <td><div align="center">Obtido ao criar um <b>Umbral Master Spellbook</b>.</div></td>
                </tr>
				<tr bgcolor="#F1E0C6">
				<td><div align="center"><img src="http://www.tibiawiki.com.br/images/f/ff/Achievement.gif" width="16" height="16"> <img src="http://www.tibiawiki.com.br/images/f/ff/Achievement.gif" width="16" height="16"></div></td>
                  <td><div align="center">Umbral Headsman</div></td>
                  <td><div align="center">Obtido ao criar uma <b>Umbral Master Axe</b>.</div></td>
                </tr>
				<tr bgcolor="#D4C0A1">
				<td><div align="center"><img src="http://www.tibiawiki.com.br/images/f/ff/Achievement.gif" width="16" height="16"> <img src="http://www.tibiawiki.com.br/images/f/ff/Achievement.gif" width="16" height="16"></div></td>
                  <td><div align="center">Umbral Marksman</div></td>
                  <td><div align="center">Obtido ao criar uma <b>Umbral Master Crossbow</b>.</div></td>
                </tr>
				<tr bgcolor="#F1E0C6">
				<td><div align="center"><img src="http://www.tibiawiki.com.br/images/f/ff/Achievement.gif" width="16" height="16"> <img src="http://www.tibiawiki.com.br/images/f/ff/Achievement.gif" width="16" height="16"></div></td>
                  <td><div align="center">Umbral Swordsman</div></td>
                  <td><div align="center">Obtido ao criar uma <b>Umbral Masterblade</b>.</div></td>
                </tr>
				<tr bgcolor="#D4C0A1">
				<td><div align="center"><img src="http://www.tibiawiki.com.br/images/f/ff/Achievement.gif" width="16" height="16"> <img src="http://www.tibiawiki.com.br/images/f/ff/Achievement.gif" width="16" height="16"> <img src="http://www.tibiawiki.com.br/images/f/ff/Achievement.gif" width="16" height="16"></div></td>
                  <td><div align="center">Umbral Master</div></td>
                  <td><div align="center">Obtido ao elevar todos os itens <b>"Umbral"</b> para <b>"Umbral Master"</b>.</div></td>
                </tr>
				</table>
				<br></>
                </TR>
				</table></div><br><div class="TableContainer">
        <div class="CaptionContainer">
                        <div class="CaptionInnerContainer">
                                <span class="CaptionEdgeLeftTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionEdgeRightTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionBorderTop" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif)"></span>
                                <span class="CaptionVerticalLeft" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif)"></span>
                                <div class="Text"><center>Como Obter os items necesarios.</center></div>
                                <span class="CaptionVerticalRight" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif)"></span>
                                <span class="CaptionBorderBottom" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif)"></span>
                                <span class="CaptionEdgeLeftBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                                <span class="CaptionEdgeRightBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif)"></span>
                        </div>
                </div> 
				<table cellpadding="4" cellspacing="1" width="100%" border="0">
				<TR BGCOLOR="#F1E0C6">
				<TD ><center>Estes items podem ser conseguidos com monsters normais, e alguns bosses.</center></TD>
				</TR>
				<TR BGCOLOR="#D4C0A1">
				<table cellpadding="4" cellspacing="1" width="100%" border="0">
				
				<TR BGCOLOR="#D4C0A1">
						<TD width="6%" ><b><center>Img</center></b></TD>
                        <TD width="15%" ><b><center>Name of item</center></b></TD>
						<TD width="50%" ><b><center>Monsters that drop</center></b></TD>
                </TR>

				<tr bgcolor="#D4C0A1">
					<td><div align="center"><img src="http://tibiawiki.com.br/images/f/f6/Dream_Matter.gif" width="32" height="32"></div></td>
                  <td><div align="center">Dream Matter</div></td>
                  <td><div align="center">
				  <img src="http://tibiawiki.com.br/images/6/63/Gaz%27Haragoth.gif" width="60" height="58" title="Gaz'Haragoth"> 
				  <img src="http://tibiawiki.com.br/images/e/e0/Horadron.gif" width="64" height="62" title="Horadron"> 
				  <img src="http://tibiawiki.com.br/images/e/e5/Omrafir.gif" width="64" height="62" title="Omrafir"> 
				  <img src="http://tibiawiki.com.br/images/c/cc/Terofar.gif" width="64" height="62" title="Terofar"> 
				  <img src="http://tibiawiki.com.br/images/a/a0/Zavarash.gif" width="64" height="62" title="Zavarash">
				 <!-- <img src="http://tibiawiki.com.br/images/2/21/Sight_of_Surrender.gif" width="64" height="61" title="Sight of Surrender"></div></td>-->
                </tr>
				<tr bgcolor="#F1E0C6">
					<td><div align="center"><img src="http://tibiawiki.com.br/images/e/e1/Cluster_of_Solace.gif" width="33" height="31"></div></td>
                  <td><div align="center">Clusters of Solace</div></td>
                  <td><div align="center">
				  <img src="http://tibiawiki.com.br/images/c/ce/Choking_Fear.gif" width="56" height="46" title="Choking Fear">
				  <img src="http://tibiawiki.com.br/images/2/22/Demon_Outcast.gif" width="49" height="53" title="Demon Outcast">
				  <img src="http://tibiawiki.com.br/images/5/53/Frazzlemaw.gif" width="32" height="32" title="Frazzlemaw">
				  <img src="http://tibiawiki.com.br/images/6/63/Gaz%27Haragoth.gif" width="60" height="58" title="Gaz'Haragoth">
				  <img src="http://tibiawiki.com.br/images/7/72/Guzzlemaw.gif" width="60" height="58" title="Guzzlemaw">
				  <img src="http://tibiawiki.com.br/images/e/e0/Horadron.gif" width="64" height="62" title="Horadron"><br>
				  <img src="http://tibiawiki.com.br/images/a/a8/Mawhawk.gif" width="60" height="62" title="Mawhawk">
				  <img src="http://tibiawiki.com.br/images/0/0c/Prince_Drazzak.gif" width="64" height="62" title="Prince Drazzak">
				  <img src="http://tibiawiki.com.br/images/7/70/Retching_Horror.gif" width="62" height="50" title="Retching Horror">
				  <img src="http://tibiawiki.com.br/images/d/dd/Silencer.gif" width="46" height="53" title="Silencer">
				  <img src="http://tibiawiki.com.br/images/2/21/Sight_of_Surrender.gif" width="64" height="61" title="Sight of Surrender">
				  <img src="http://tibiawiki.com.br/images/4/45/Shiversleep.gif" width="58" height="63" title="Shiversleep"><br>
				  <img src="http://tibiawiki.com.br/images/e/e5/Omrafir.gif" width="64" height="62" title="Omrafir">
				  <img src="http://tibiawiki.com.br/images/c/cc/Terofar.gif" width="64" height="62" title="Terofar">
				  <img src="http://tibiawiki.com.br/images/a/a0/Zavarash.gif" width="64" height="62" title="Zavarash"></div></td>
                </tr>
				</table>
				<br></>
                </TR>
				</table></div><br>
 
      </div>
      </div>
    </div>