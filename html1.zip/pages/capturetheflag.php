
<html>
<center>
<td>
<center><h2><b><font color=red>CAPTURE THE FLAG</font></b></h2></center><br><br>

<center><img src="/images/ctf/Screenshot_6.png" width=280 height=250>  <img src="/images/ctf/Screenshot_7.png" width=250 height=250></center>
</center><br><br>
<div class="TableContainer">
	<div class="CaptionContainer">
		<div class="CaptionInnerContainer">
			<span class="CaptionEdgeLeftTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
			<span class="CaptionEdgeRightTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
			<span class="CaptionBorderTop" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);"></span>
			<span class="CaptionVerticalLeft" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span>
			<div class="Text">Informa&ccedil;&otilde;es Capture the flag Event</div>
			<span class="CaptionVerticalRight" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span>
			<span class="CaptionBorderBottom" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);"></span>
			<span class="CaptionEdgeLeftBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
			<span class="CaptionEdgeRightBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
				</div>
					</div>
						<table class="Table5" cellpadding="0" cellspacing="0">
							<tbody>
								<tr>
									<td>
									<div class="InnerTableContainer">
										<table style="width:100%;">
											<tbody>
												<tr>
													<td>
														<div class="TableShadowContainerRightTop">
															<div class="TableShadowRightTop" style="background-image:url('.$layout_name.'/images/content/table-shadow-rt.gif);"></div>
														</div>
													<div class="TableContentAndRightShadow" style="background-image:url('.$layout_name.'/images/content/table-shadow-rm.gif);">
													<div class="TableContentContainer">
<center>
<table width="100%" border="0" cellpadding="4" cellspacing="1">
<tbody>
	<tr>
		<td colspan="3" bgcolor="#f1e0c6"><span class="style4">
O evento acontece todas as <b>Quartas-feiras</b> às <b>20:00hrs</b>, <b>Sábados</b> e <b>Domingos</b> as <b>16:00hrs</b>. No horario citado aparecerá uma mensagem vermelha na tela informando o inicio do evento, aparecerá também um teleport no depot de Thais, que ficará aberto por 10 minutos. Para participar do evento o jogador deve entrar nesse teleport e aguardar na sala de espera.</b>.</span><br>
		</td>
	</tr>
	<tr bgcolor="#d4c0a1"><td width="35%">
O evento dividirá os jogadores participantes em 2 equipes, <b>blue</b> e <b>red</b> com numeros iguais de participantes.<br>
		</td>
	</tr>
	<td colspan="3" bgcolor="#f1e0c6"><span class="style4">
Os jogadores de cada time terá um templo e em cima desse templo tem uma montanha que tem a <b>bandeira</b> que deve ser <b>protegida</b> do time adversario.</span>
		</td>
	<tr bgcolor="#d4c0a1"><td width="35%">
O objetivo desse evento é <b>capturar 15 bandeiras inimigas</b>. O Time blue e red tem que ir até a base inimiga, capturar a bandeira e retornar até a sua base, só assim o time irá pontuar. <b>Apenas um jogador de cada time pode carregar a bandeira.</b> Ex.: O Jogador ADM Support é do time Vermelho e capturou a bandeira do time Azul, então o ADM Support tem que retornar até a base do time vermelho e levar a bandeira para contabilizar no placar.<br>
		</td>
	</tr>
	<td colspan="3" bgcolor="#f1e0c6"><span class="style4">
Quando o jogador está com a bandeira ele ficará com uma cor diferente. Vermelho ficará com a cor <b>Vermelho escuro</b>, e Azul ficará com a cor de <b>Azul claro</b>.</span><br>
		</td>
	<tr bgcolor="#d4c0a1"><td width="35%">
Dica: Alem de se preocupar com a captura da bandeira, é recomendado fixar os ataque nos jogadores que estão com vermelho escuro e azul claro, esses são os jogadores que devem ser mortos para o time adversario não pontuar.<br>
		</td>
	</tr>
	<td colspan="3" bgcolor="#f1e0c6"><span class="style4">
Caso o jogador que está com a bandeira morra, está voltará ao seu local de origem, tendo que outro jogador do time ir busca-la.</span><br>
		</td>
	<tr bgcolor="#d4c0a1"><td width="35%">
A cada bandeira capturada o servidor emitirá uma mensagem pelo Server Log informando o atual placar do evento.	
		</td>
	</tr>
	<td colspan="3" bgcolor="#f1e0c6"><span class="style4">
Quando o jogador morre, este é enviado para um <b>cemiterio</b> que ficará lá por alguns segundos, porem esses segundos aumentam de acordo com a quantidade de mortes do participante. Ex.: Jogador GOD Aurera morreu 1 vez, ele ficará nesse cemiterio 5 segundos, caso ele morra 5 vezes, ele ficará 25 segundos, o tempo maximo de espera é de 50 segundos.</span><br>
		</td>
	<tr bgcolor="#d4c0a1"><td width="35%">
Obs.: Quando o jogador entra no evento, só é possivel sair apos a finalização do mesmo.	
		</td>
	</tr>
	<td colspan="3" bgcolor="#f1e0c6"><span class="style4">
Quando um dos times marcar 15 pontos (15 bandeiras), todos os participantes são enviados para o templo, e o time vencedor ganhará <b>10 bars of gold</b>.
	</td>
</tbody>
</table>
</center>
								</div>
									</div>
										<div class="TableShadowContainer">
											<div class="TableBottomShadow" style="background-image:url('.$layout_name.'/images/content/table-shadow-bm.gif);">
											<div class="TableBottomLeftShadow" style="background-image:url('.$layout_name.'/images/content/table-shadow-bl.gif);"></div>
											<div class="TableBottomRightShadow" style="background-image:url('.$layout_name.'/images/content/table-shadow-br.gif);"></div>
										</div>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</td>
			</tr>
		</tbody>
	</table>
</div>
</html>